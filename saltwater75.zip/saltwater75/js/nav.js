/**
 * Saltwater 75 — navigation behaviour.
 * Sticky header state on scroll, mobile toggle, dropdowns, subscribe confirmation.
 */
(function () {
	'use strict';

	var header = document.querySelector('.site-header[data-sticky]');
	var toggle = document.querySelector('.nav-toggle');
	var nav    = document.getElementById('site-navigation');

	// Solid header once the user scrolls past the hero-ish threshold.
	function onScroll() {
		if (!header) return;
		if (window.scrollY > 40) {
			header.classList.add('is-scrolled');
		} else {
			header.classList.remove('is-scrolled');
		}
	}
	window.addEventListener('scroll', onScroll, { passive: true });
	onScroll();

	// Mobile menu toggle.
	if (toggle && nav) {
		toggle.addEventListener('click', function () {
			var open = header.classList.toggle('nav-open');
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		});

		// Tap-to-open submenus on touch / small screens.
		nav.querySelectorAll('.menu-item-has-children > a').forEach(function (link) {
			link.addEventListener('click', function (e) {
				if (window.matchMedia('(max-width: 900px)').matches) {
					e.preventDefault();
					link.parentElement.classList.toggle('is-open');
				}
			});
		});

		// Close the mobile menu after picking an in-page link.
		nav.querySelectorAll('a[href^="#"]').forEach(function (link) {
			link.addEventListener('click', function () {
				header.classList.remove('nav-open');
				toggle.setAttribute('aria-expanded', 'false');
			});
		});
	}

	// Fake subscribe confirmation (mirrors the original "Thanks for subscribing!").
	var form = document.querySelector('.subscribe__form');
	var note = document.querySelector('.subscribe__note');
	if (form && note) {
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			if (!form.checkValidity()) { form.reportValidity(); return; }
			form.hidden = true;
			note.hidden = false;
		});
	}
})();
