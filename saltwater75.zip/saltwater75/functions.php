<?php
/**
 * Saltwater 75 theme functions.
 *
 * @package Saltwater75
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'SALTWATER75_VERSION', '1.0.0' );

/**
 * Images are hot-linked from the original site's Wix CDN, as requested.
 * Central map so the URLs live in one place. Use saltwater75_img( 'key' ).
 */
function saltwater75_images() {
	$base = 'https://static.wixstatic.com/media/';
	return array(
		'logo'      => $base . 'c57fb0_ff950f6488bf48a5b535d179ea75521a~mv2.png', // swlogoglow.png
		'hero'      => $base . '8b7d81_9e0c692749f1458fac87316b08175b36~mv2.jpg', // DSC00436 – bay
		'about'     => $base . '8b7d81_f8c20e63681c48e1a9abb79a7f5e4756~mv2.jpg', // DSC00335
		'gallery_1' => $base . '8b7d81_fac878ca6621489296d01c593d187e87~mv2.jpg',
		'gallery_2' => $base . '8b7d81_f1665d67599d4baba7a5aa082cd31c27~mv2.jpg',
		'gallery_3' => $base . '8b7d81_20399a78150d4aa5bd46b15175849306~mv2.jpg', // kayak
		'gallery_4' => $base . '8b7d81_4578ab8a85194bbf8a068a0aa2a69166~mv2.jpg',
		'gallery_5' => $base . '8b7d81_fac94caea9154a1a8c82412cd26aa030~mv2.jpg',
		'gallery_6' => $base . '8b7d81_6236fb9170a1446585495d1908d55e1e~mv2.jpg',
		'gallery_7' => $base . '8b7d81_d75404662ebc4e53810e158d04ebcdf7~mv2.jpg',
		'gallery_8' => $base . '8b7d81_922685b962d5451d91b0b89b36ba2106~mv2.jpg',
		'icon_ig'   => $base . '01c3aff52f2a4dffa526d7a9843d46ea.png',
		'icon_fb'   => $base . '0fdef751204647a3bbd7eaa2827ed4f9.png',
		'icon_tt'   => $base . '11062b_6e7994bdd94b41178720ff1641a0f323~mv2.png',
	);
}

function saltwater75_img( $key ) {
	$images = saltwater75_images();
	return isset( $images[ $key ] ) ? esc_url( $images[ $key ] ) : '';
}

/**
 * Theme setup.
 */
function saltwater75_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 92, 'width' => 251, 'flex-height' => true, 'flex-width' => true ) );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'saltwater75' ),
	) );
}
add_action( 'after_setup_theme', 'saltwater75_setup' );

/**
 * Content width.
 */
function saltwater75_content_width() {
	$GLOBALS['content_width'] = 1200;
}
add_action( 'after_setup_theme', 'saltwater75_content_width', 0 );

/**
 * Styles & scripts.
 */
function saltwater75_scripts() {
	// Google Fonts – Playfair Display (headings) + Montserrat (body) to echo the original serif/sans pairing.
	wp_enqueue_style(
		'saltwater75-fonts',
		'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800&family=Montserrat:wght@300;400;500;600;700&display=swap',
		array(),
		null
	);

	wp_enqueue_style( 'saltwater75-style', get_stylesheet_uri(), array( 'saltwater75-fonts' ), SALTWATER75_VERSION );

	wp_enqueue_script( 'saltwater75-nav', get_template_directory_uri() . '/js/nav.js', array(), SALTWATER75_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'saltwater75_scripts' );

/**
 * Fallback menu — shown when no menu is assigned to the "primary" location,
 * so the theme mirrors saltwater75.com immediately after activation.
 */
function saltwater75_default_menu() {
	$items = array(
		array( 'label' => 'Home', 'url' => home_url( '/' ) ),
		array( 'label' => 'Happy Hour', 'url' => '#happy-hour' ),
		array( 'label' => 'Menu', 'url' => '#menu' ),
		array(
			'label' => 'Store',
			'url'   => '#store',
			'sub'   => array( 'Accessories', 'T-Shirts', 'Hats', 'Long Sleeve + Sweatshirts', 'Gift Cards + AO Game Card', 'Full Catalog' ),
		),
		array( 'label' => 'Entertainment', 'url' => '#entertainment' ),
		array(
			'label' => 'Contact',
			'url'   => '#contact',
			'sub'   => array( 'Plan A Party!', 'Frequently Asked', 'Employment' ),
		),
		array( 'label' => 'More', 'url' => '#more' ),
	);

	echo '<ul id="primary-menu" class="menu nav-menu">';
	foreach ( $items as $item ) {
		$has_children = ! empty( $item['sub'] );
		$classes      = 'menu-item' . ( $has_children ? ' menu-item-has-children' : '' );
		printf( '<li class="%s"><a href="%s">%s</a>', esc_attr( $classes ), esc_url( $item['url'] ), esc_html( $item['label'] ) );
		if ( $has_children ) {
			echo '<ul class="sub-menu">';
			foreach ( $item['sub'] as $sub ) {
				printf( '<li class="menu-item"><a href="#">%s</a></li>', esc_html( $sub ) );
			}
			echo '</ul>';
		}
		echo '</li>';
	}
	echo '</ul>';
}
